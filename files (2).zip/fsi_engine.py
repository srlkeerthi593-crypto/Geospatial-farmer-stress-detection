"""
src/logic/fsi_engine.py
-----------------------
Computes the Farmer Stress Index (FSI) for each district.

FSI is a weighted composite of normalised stress indicators.
Higher FSI  →  more stressed.
"""

import pandas as pd
import numpy as np

# ── Indicator weights (must sum to 1.0) ─────────────────────────────────────
# Positive weight  = higher raw value → higher stress
# Negative weight  = higher raw value → LOWER stress  (invert before scoring)

INDICATOR_CONFIG = {
    # column                   weight   invert?
    "rainfall_mm":           (-0.20,   True ),   # low rain → high stress
    "rainfall_deviation":    (-0.10,   True ),   # negative dev → stress
    "crop_yield":            (-0.20,   True ),   # low yield → stress
    "yield_index":           (-0.10,   True ),   # below baseline → stress
    "market_price":          (-0.10,   True ),   # low price → stress
    "price_deviation":       (-0.10,   True ),   # negative deviation → stress
    "cultivation_cost":      ( 0.20,   False),   # high cost → stress
}


def _minmax(series: pd.Series) -> pd.Series:
    """Min-max normalise to [0, 1]. Returns 0.5 if all values are equal."""
    mn, mx = series.min(), series.max()
    if mx == mn:
        return pd.Series(0.5, index=series.index)
    return (series - mn) / (mx - mn)


def compute_fsi(df: pd.DataFrame) -> pd.DataFrame:
    """
    Given a merged district DataFrame, compute and attach:
        - FSI_Score  (float, 0–1)
        - FSI_Raw    (pre-clip float)

    Returns the same DataFrame with new columns appended.
    """
    df = df.copy()
    score = pd.Series(0.0, index=df.index)
    total_weight = 0.0

    for col, (weight, invert) in INDICATOR_CONFIG.items():
        if col not in df.columns:
            continue
        s = pd.to_numeric(df[col], errors="coerce").fillna(df[col].median()
                          if df[col].notna().any() else 0)
        normed = _minmax(s)
        if invert:
            normed = 1.0 - normed          # flip: low raw → high stress
        score      += abs(weight) * normed
        total_weight += abs(weight)

    if total_weight > 0:
        score = score / total_weight       # re-normalise to [0, 1]

    df["FSI_Raw"]   = score
    df["FSI_Score"] = score.clip(0, 1).round(4)
    return df
