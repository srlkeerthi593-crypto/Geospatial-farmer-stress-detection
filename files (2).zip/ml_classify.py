"""
src/logic/ml_classify.py
-------------------------
Uses Scikit-learn to classify districts into LOW / MEDIUM / HIGH stress
based on the computed FSI_Score and selected indicator features.

Two-step approach:
  1. KMeans clustering (unsupervised) — finds natural groupings
  2. Labels clusters as LOW / MEDIUM / HIGH by mean FSI rank
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier


def classify_stress(
    df: pd.DataFrame,
    feature_cols: list = None,
    n_clusters: int = 3,
    random_state: int = 42,
) -> pd.DataFrame:
    """
    Classify each district into a stress category.

    Parameters
    ----------
    df           : DataFrame with FSI_Score + indicator columns
    feature_cols : list of indicator column names to use as features
                   (falls back to FSI_Score only if none are available)
    n_clusters   : number of stress tiers (default 3)
    random_state : reproducibility seed

    Returns
    -------
    df with new columns:
        Stress_Level  — "LOW" | "MEDIUM" | "HIGH"
        Stress_Prob   — confidence score (0–1) from Random Forest
    """
    df = df.copy()

    # ── Build feature matrix ─────────────────────────────────────────────
    available = ["FSI_Score"]
    if feature_cols:
        available += [c for c in feature_cols if c in df.columns and c != "FSI_Score"]

    X = df[available].copy()
    X = X.fillna(X.median())

    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)

    # ── KMeans clustering ────────────────────────────────────────────────
    n = min(n_clusters, len(df))
    km = KMeans(n_clusters=n, random_state=random_state, n_init=10)
    cluster_labels = km.fit_predict(X_scaled)

    df["_cluster"] = cluster_labels

    # ── Map cluster IDs → stress level by mean FSI rank ──────────────────
    cluster_means = (
        df.groupby("_cluster")["FSI_Score"].mean().sort_values()
    )
    level_map_raw = {
        cid: lvl
        for cid, lvl in zip(
            cluster_means.index,
            ["LOW", "MEDIUM", "HIGH"][:len(cluster_means)]
        )
    }
    df["Stress_Level"] = df["_cluster"].map(level_map_raw)
    df.drop(columns=["_cluster"], inplace=True)

    # ── Random Forest for probability / confidence ───────────────────────
    label_enc = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}
    y = df["Stress_Level"].map(label_enc)

    if len(df) >= 6:   # enough samples for RF
        rf = RandomForestClassifier(
            n_estimators=100, random_state=random_state, max_depth=4
        )
        rf.fit(X_scaled, y)
        proba = rf.predict_proba(X_scaled)
        y_pred = rf.predict(X_scaled)
        # confidence = probability of the assigned class
        inv_enc = {v: k for k, v in label_enc.items()}
        df["Stress_Level"] = [inv_enc[p] for p in y_pred]
        df["Stress_Prob"]  = proba.max(axis=1).round(3)
    else:
        df["Stress_Prob"] = 1.0

    return df
