"""
src/logic/hotspot.py
--------------------
Spatial hotspot detection using:
  - Getis-Ord Gi* statistic  (PySAL / esda)
  - Moran's I for global spatial autocorrelation

Falls back to FSI-threshold method if PySAL is unavailable
(e.g., during development without spatial libs installed).
"""

import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

try:
    import libpysal
    from esda.getisord import G_Local
    from esda.moran import Moran
    PYSAL_AVAILABLE = True
except ImportError:
    PYSAL_AVAILABLE = False


def detect_hotspots(
    df: pd.DataFrame,
    threshold: float = 0.65,
    lat_col: str = "lat",
    lon_col: str = "lon",
    value_col: str = "FSI_Score",
) -> pd.DataFrame:
    """
    Tag each district as a hotspot (True/False).

    If PySAL is available AND lat/lon columns exist:
        → Uses Getis-Ord Gi* (p < 0.05 + positive z-score)
    Else:
        → Simple threshold: FSI_Score > threshold

    Also computes Moran's I if possible.

    Returns df with:
        Hotspot        — bool
        Gi_ZScore      — float (Gi* z-score, if computed)
        Gi_PValue      — float (p-value, if computed)
        Morans_I       — float (global, scalar, if computed)
    """
    df = df.copy()

    # ── Ensure lat/lon exist (use centroids from our sample data) ─────────
    if lat_col not in df.columns or lon_col not in df.columns:
        # Attach Karnataka district centroids as fallback
        df = _attach_ka_centroids(df)

    has_coords = (lat_col in df.columns and lon_col in df.columns
                  and df[lat_col].notna().all())

    if PYSAL_AVAILABLE and has_coords and len(df) >= 4:
        df = _pysal_hotspot(df, lat_col, lon_col, value_col)
    else:
        df["Hotspot"]   = df[value_col] > threshold
        df["Gi_ZScore"] = np.nan
        df["Gi_PValue"] = np.nan
        df["Morans_I"]  = np.nan

    return df


def _pysal_hotspot(df, lat_col, lon_col, value_col):
    """Run Gi* via PySAL libpysal + esda."""
    coords = list(zip(df[lon_col], df[lat_col]))

    # KNN weights (k=4 — robust for small n)
    k = min(4, len(df) - 1)
    w = libpysal.weights.KNN.from_array(np.array(coords), k=k)
    w.transform = "R"   # row-standardise

    y = df[value_col].fillna(df[value_col].median()).values

    # Getis-Ord Gi*
    gi = G_Local(y, w, transform="R", star=True, permutations=199)
    df["Gi_ZScore"] = gi.Zs.round(4)
    df["Gi_PValue"] = gi.p_sim.round(4)
    df["Hotspot"]   = (gi.Zs > 1.65) & (gi.p_sim < 0.05)   # 90% confidence

    # Moran's I (global)
    try:
        mi = Moran(y, w, permutations=199)
        df["Morans_I"] = round(float(mi.I), 4)
    except Exception:
        df["Morans_I"] = np.nan

    return df


# ── Karnataka district centroids (fallback) ──────────────────────────────────
KA_CENTROIDS = {
    "Bagalkot":16.1826,"Bagalkot_lon":75.6961,
    "Bangalore Rural":13.2257,"Bangalore Rural_lon":77.5824,
    "Bangalore":12.9716,"Bangalore_lon":77.5946,
    "Belgaum":15.8497,"Belgaum_lon":74.4977,
    "Bellary":15.1394,"Bellary_lon":76.9214,
    "Bidar":17.9104,"Bidar_lon":77.5199,
    "Bijapur":16.8302,"Bijapur_lon":75.7100,
    "Chamrajnagar":11.9261,"Chamrajnagar_lon":76.9437,
    "Chikballapura":13.4355,"Chikballapura_lon":77.7315,
    "Chikmagalur":13.3161,"Chikmagalur_lon":75.7720,
    "Chitradurga":14.2226,"Chitradurga_lon":76.3985,
    "Dakshina Kannada":12.8438,"Dakshina Kannada_lon":75.2479,
    "Davanagere":14.4644,"Davanagere_lon":75.9218,
    "Dharwad":15.4589,"Dharwad_lon":75.0078,
    "Gadag":15.4166,"Gadag_lon":75.6244,
    "Gulbarga":17.3297,"Gulbarga_lon":76.8343,
    "Hassan":12.9918,"Hassan_lon":76.0980,
    "Haveri":14.7957,"Haveri_lon":75.3996,
    "Kodagu":12.3375,"Kodagu_lon":75.8069,
    "Kolar":13.1360,"Kolar_lon":78.1294,
    "Koppal":15.3483,"Koppal_lon":76.1546,
    "Mandya":12.5218,"Mandya_lon":76.8951,
    "Mysore":12.2958,"Mysore_lon":76.6394,
    "Raichur":16.2120,"Raichur_lon":77.3439,
    "Ramanagara":12.7157,"Ramanagara_lon":77.2818,
    "Shimoga":13.9299,"Shimoga_lon":75.5681,
    "Tumkur":13.3379,"Tumkur_lon":77.1173,
    "Udupi":13.3409,"Udupi_lon":74.7421,
    "Uttara Kannada":14.9784,"Uttara Kannada_lon":74.7645,
    "Vijayanagar":15.1645,"Vijayanagar_lon":76.4600,
    "Yadgir":16.7713,"Yadgir_lon":77.1383,
}

def _attach_ka_centroids(df: pd.DataFrame) -> pd.DataFrame:
    lats, lons = [], []
    for _, row in df.iterrows():
        d = row.get("district_norm", row.get("District",""))
        lats.append(KA_CENTROIDS.get(d, KA_CENTROIDS.get(d + "_lat", 15.3)))
        lons.append(KA_CENTROIDS.get(d + "_lon", 75.7))
    df = df.copy()
    df["lat"] = lats
    df["lon"] = lons
    return df
