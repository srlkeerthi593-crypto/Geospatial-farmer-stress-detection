"""
AgriStress Avengers — FSI Command Dashboard
main.py  ·  Entry point

Run:
    streamlit run main.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import zipfile, os, time, io, json, warnings
warnings.filterwarnings("ignore")

import plotly.express as px
import plotly.graph_objects as go
import geopandas as gpd
from shapely.geometry import shape
import struct

# ── Phase 2 logic modules ────────────────────────────────────────────────────
from src.logic.fsi_engine   import compute_fsi
from src.logic.hotspot      import detect_hotspots
from src.logic.ml_classify  import classify_stress

# ════════════════════════════════════════════════════════════════════════════
# PAGE CONFIG
# ════════════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title="AgriStress Avengers",
    page_icon="🌾",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ════════════════════════════════════════════════════════════════════════════
# GLOBAL CSS  —  Game-HUD Aesthetic (matches reference image)
# ════════════════════════════════════════════════════════════════════════════
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@400;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Rajdhani', sans-serif;
    background-color: #050e05;
    color: #c8f0c0;
}
.stApp {
    background: radial-gradient(ellipse at top, #0a1a0a 0%, #050e05 60%, #020802 100%);
}
.stApp::before {
    content:'';
    position:fixed; top:0; left:0; right:0; bottom:0;
    background: repeating-linear-gradient(0deg,transparent,transparent 2px,
        rgba(0,255,80,.015) 2px, rgba(0,255,80,.015) 4px);
    pointer-events:none; z-index:9999;
}

/* ── TITLE ── */
.game-title {
    font-family:'Orbitron',monospace; font-size:2.6rem; font-weight:900;
    color:#00ff50;
    text-shadow:0 0 20px #00ff50,0 0 50px #00cc40,0 0 100px #006618;
    letter-spacing:6px; text-align:center; padding:1rem 0 .2rem;
    animation: flicker 5s infinite;
}
@keyframes flicker {
    0%,94%,100%{opacity:1} 95%{opacity:.8} 96%{opacity:1} 98%{opacity:.7}
}
.game-subtitle {
    font-family:'Rajdhani',sans-serif; font-size:.95rem; color:#40aa50;
    text-align:center; letter-spacing:8px; text-transform:uppercase;
    margin-bottom:1.5rem;
}

/* ── HUD CARDS ── */
.hud-card {
    background:linear-gradient(145deg,rgba(0,25,8,.95),rgba(0,15,4,.98));
    border:1px solid #00ff5035; border-left:3px solid #00ff50;
    border-radius:3px; padding:.9rem 1.1rem; margin-bottom:.8rem;
    box-shadow:0 0 18px rgba(0,255,80,.07),inset 0 0 30px rgba(0,255,80,.025);
    position:relative; overflow:hidden;
}
.hud-card::after {
    content:''; position:absolute; top:0; right:0;
    width:35px; height:35px;
    border-top:2px solid #00ff5055; border-right:2px solid #00ff5055;
}
.hud-label {
    font-family:'Orbitron',monospace; font-size:.6rem; color:#35bb50;
    letter-spacing:3px; text-transform:uppercase; margin-bottom:.25rem;
}
.hud-value {
    font-family:'Orbitron',monospace; font-size:1.7rem; font-weight:700;
    color:#00ff50; text-shadow:0 0 12px #00ff5070;
}

/* ── BADGES ── */
.badge-low    {background:#001a00;border:1px solid #00ff50;color:#00ff50;padding:2px 10px;border-radius:2px;font-family:'Orbitron',monospace;font-size:.65rem;letter-spacing:2px;}
.badge-medium {background:#2a1a00;border:1px solid #ffaa00;color:#ffaa00;padding:2px 10px;border-radius:2px;font-family:'Orbitron',monospace;font-size:.65rem;letter-spacing:2px;}
.badge-high   {background:#2a0000;border:1px solid #ff3300;color:#ff3300;padding:2px 10px;border-radius:2px;font-family:'Orbitron',monospace;font-size:.65rem;letter-spacing:2px;}

/* ── SECTION HEADERS ── */
.section-header {
    font-family:'Orbitron',monospace; font-size:.72rem; color:#00ff50;
    letter-spacing:4px; text-transform:uppercase;
    border-bottom:1px solid #00ff5025; padding-bottom:.35rem; margin:1rem 0 .7rem;
}

/* ── PROGRESS BARS ── */
.stress-bar-bg  {background:#001200;border-radius:2px;height:7px;border:1px solid #00ff5020;}
.stress-bar-fill{height:5px;border-radius:1px;margin:1px;transition:width 1s ease;}

/* ── BUTTONS ── */
.stButton>button {
    font-family:'Orbitron',monospace !important; font-size:.7rem !important;
    letter-spacing:3px !important;
    background:linear-gradient(135deg,#002800,#001200) !important;
    color:#00ff50 !important; border:1px solid #00ff5055 !important;
    border-radius:2px !important; padding:.55rem 1.2rem !important;
    text-transform:uppercase !important;
    box-shadow:0 0 12px rgba(0,255,80,.08) !important;
    transition:all .2s !important; width:100%;
}
.stButton>button:hover {
    background:linear-gradient(135deg,#003800,#001c00) !important;
    box-shadow:0 0 28px rgba(0,255,80,.28) !important;
    border-color:#00ff50 !important; transform:translateY(-1px) !important;
}

/* ── SIDEBAR ── */
[data-testid="stSidebar"] {
    background:linear-gradient(180deg,#040d04 0%,#070f07 100%) !important;
    border-right:1px solid #00ff5018 !important;
}
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] .stSelectbox label,
[data-testid="stSidebar"] .stSlider label {
    font-family:'Orbitron',monospace !important; font-size:.6rem !important;
    color:#35bb50 !important; letter-spacing:2px !important;
    text-transform:uppercase !important;
}

/* ── METRICS ── */
[data-testid="metric-container"] {
    background:rgba(0,25,8,.85) !important;
    border:1px solid #00ff5028 !important; border-radius:3px !important;
    padding:.7rem !important;
}
[data-testid="metric-container"] label {
    font-family:'Orbitron',monospace !important; font-size:.6rem !important;
    color:#35bb50 !important; letter-spacing:2px !important;
}

/* ── MISSION LOG ── */
.mission-log {
    background:#030a03; border:1px solid #00ff5020; border-radius:3px;
    padding:.7rem .9rem; font-family:'Rajdhani',monospace;
    font-size:.88rem; color:#35aa45; line-height:1.9;
    max-height:200px; overflow-y:auto;
}
.log-line      {color:#2a9a3a;}
.log-line-warn {color:#ffaa00;}
.log-line-alert{color:#ff4422;}
.log-time      {color:#004d10; margin-right:.4rem;}

/* ── DATAFRAME ── */
.stDataFrame {border:1px solid #00ff5025 !important; border-radius:3px;}

/* ── ALERTS ── */
.stAlert{border-radius:2px !important;border-left:3px solid #00ff50 !important;
         background:rgba(0,255,80,.04) !important;}

/* ── FOOTER ── */
.footer {
    text-align:center; margin-top:2rem; padding:1rem;
    border-top:1px solid #00ff5012;
    font-family:'Orbitron',monospace; font-size:.58rem;
    color:#004d10; letter-spacing:3px;
}
</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════════════════
# SESSION STATE
# ════════════════════════════════════════════════════════════════════════════
for k, v in [("analysis_done", False), ("fsi_data", None),
             ("geo_data", None), ("xp", 0), ("level", 1), ("log", [])]:
    if k not in st.session_state:
        st.session_state[k] = v

def add_log(msg, kind="normal"):
    ts = time.strftime("%H:%M:%S")
    st.session_state.log.insert(0, (ts, msg, kind))
    st.session_state.log = st.session_state.log[:25]

def gain_xp(pts):
    st.session_state.xp += pts
    cap = st.session_state.level * 100
    if st.session_state.xp >= cap:
        st.session_state.xp -= cap
        st.session_state.level += 1
        add_log(f"LEVEL UP → LEVEL {st.session_state.level}  +{pts} XP", "alert")
    else:
        add_log(f"Mission reward: +{pts} XP", "normal")

# ════════════════════════════════════════════════════════════════════════════
# DATA LOADERS
# ════════════════════════════════════════════════════════════════════════════

# ── Name normaliser (match Excel ↔ shapefile) ────────────────────────────
NAME_MAP = {
    # Excel name           → Shapefile NAME_2
    "bangalore rural"      : "Bangalore Rural",
    "bengaluru urban"      : "Bangalore",
    "bijapur"              : "Bijapur",
    "gulbarga"             : "Gulbarga",
    "dakshin kannad"       : "Dakshina Kannada",
    "uttar kannad"         : "Uttara Kannada",
    "shimoga"              : "Shimoga",
    "mysore"               : "Mysore",
    "tumkur"               : "Tumkur",
    "chikballapur"         : "Chikballapura",
    "chikmagalur"          : "Chikmagalur",
    "chamrajnagar"         : "Chamrajnagar",
    "davangere"            : "Davanagere",
    "chamarajanagar"       : "Chamrajnagar",
    "vijayanagar"          : "Vijayanagar",     # may be missing from older shapefile
    "yadgir"               : "Yadgir",
}

def normalise(name: str) -> str:
    n = name.strip().lower()
    return NAME_MAP.get(n, name.strip().title())


@st.cache_data(show_spinner=False)
def load_excel(file_bytes) -> dict:
    """Return dict of DataFrames keyed by sheet name (skip README)."""
    xl = pd.ExcelFile(io.BytesIO(file_bytes))
    sheets = {}
    for s in xl.sheet_names:
        if s.upper() == "README":
            continue
        sheets[s] = xl.parse(s)
    return sheets


@st.cache_data(show_spinner=False)
def load_shapefile(zip_bytes, state_filter="Karnataka") -> gpd.GeoDataFrame:
    """Extract zip → load level-2 shapefile → filter to state."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
            z.extractall(tmp)
        shp = os.path.join(tmp, "gadm41_IND_2.shp")
        gdf = gpd.read_file(shp)
    gdf = gdf[gdf["NAME_1"] == state_filter].copy()
    gdf = gdf.to_crs("EPSG:4326")
    gdf["district_norm"] = gdf["NAME_2"].apply(lambda x: x.strip().title())
    return gdf


def build_fsi_dataframe(sheets: dict, year: int, state: str) -> pd.DataFrame:
    """
    Merge Rainfall + Crop_Production + Market_Prices + Cultivation_Costs
    for the chosen state & year, then compute FSI.
    """
    # ── Rainfall: aggregate monthly → annual mean ────────────────────────
    rain = sheets["Rainfall"]
    rain = rain[(rain["State"] == state) & (rain["Year"] == year)].copy()
    rain_agg = rain.groupby("District").agg(
        rainfall_mm        = ("Rainfall_mm_Actual", "sum"),
        rainfall_deviation = ("Deviation_Pct", "mean"),
    ).reset_index()

    # ── Crop Production: latest year available ───────────────────────────
    prod = sheets["Crop_Production"]
    yr_str = f"{year}-{str(year+1)[-2:]}"
    prod = prod[(prod["State"] == state) & (prod["Agricultural_Year"] == yr_str)].copy()
    prod_agg = prod.groupby("District").agg(
        crop_yield         = ("Yield_Kg_per_Ha", "mean"),
        yield_index        = ("Yield_Index_vs_2015", "mean"),
    ).reset_index()

    # ── Market Prices ────────────────────────────────────────────────────
    mkt = sheets["Market_Prices"]
    mkt = mkt[(mkt["State"] == state) & (mkt["Year"] == year)].copy()
    mkt_agg = mkt.groupby("District").agg(
        market_price       = ("Market_Price_Rs_per_Quintal", "mean"),
        price_deviation    = ("Price_Deviation_Pct", "mean"),
    ).reset_index()

    # ── Cultivation Costs ────────────────────────────────────────────────
    cost = sheets["Cultivation_Costs"]
    cost = cost[(cost["State"] == state) & (cost["Year"] == year)].copy()
    cost_agg = cost.groupby("District").agg(
        cultivation_cost   = ("Total_Cost_Rs_per_Ha", "mean"),
    ).reset_index()

    # ── Merge all on District ────────────────────────────────────────────
    df = rain_agg.copy()
    for other in [prod_agg, mkt_agg, cost_agg]:
        df = df.merge(other, on="District", how="outer")

    df["district_norm"] = df["District"].apply(normalise)

    # ── Compute FSI ───────────────────────────────────────────────────────
    df = compute_fsi(df)
    return df


# ════════════════════════════════════════════════════════════════════════════
# HEADER
# ════════════════════════════════════════════════════════════════════════════
st.markdown('<div class="game-title">⚡ AGRISTRESS AVENGERS ⚡</div>', unsafe_allow_html=True)
st.markdown('<div class="game-subtitle">Farmer Stress Intelligence System · FSI Command</div>',
            unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown('<div class="section-header">🧑‍🚀 Agent Profile</div>', unsafe_allow_html=True)
    agent_name = st.text_input("AGENT ID", value="FIELD_ANALYST_01")

    xp_pct = int((st.session_state.xp / max(st.session_state.level * 100, 1)) * 100)
    st.markdown(f"""
    <div class="hud-card">
        <div class="hud-label">Level</div>
        <div class="hud-value">{st.session_state.level:02d}</div>
        <div class="hud-label" style="margin-top:.5rem;">
            XP — {st.session_state.xp}/{st.session_state.level*100}
        </div>
        <div class="stress-bar-bg">
            <div class="stress-bar-fill"
                 style="width:{xp_pct}%;background:linear-gradient(90deg,#008820,#00ff50);">
            </div>
        </div>
    </div>""", unsafe_allow_html=True)

    st.markdown('<div class="section-header">🗺 Mission Config</div>', unsafe_allow_html=True)
    selected_state = st.selectbox("TARGET STATE", ["Karnataka", "Andhra Pradesh"])
    selected_year  = st.selectbox("DATA YEAR", list(range(2023, 2014, -1)), index=0)

    indicators = st.multiselect("STRESS INDICATORS", [
        "rainfall_mm", "rainfall_deviation", "crop_yield",
        "yield_index", "market_price", "price_deviation", "cultivation_cost"
    ], default=["rainfall_mm", "crop_yield", "market_price", "cultivation_cost"])

    hotspot_threshold = st.slider("HOTSPOT SENSITIVITY (Gi*)", 0.0, 1.0, 0.65, 0.05)

    st.markdown('<div class="section-header">📡 Data Upload</div>', unsafe_allow_html=True)
    uploaded_xlsx = st.file_uploader("AGRICULTURE DATASET (XLSX)", type=["xlsx"])
    uploaded_zip  = st.file_uploader("BOUNDARY SHAPEFILE (ZIP)",   type=["zip"])

# ════════════════════════════════════════════════════════════════════════════
# MAIN LAYOUT
# ════════════════════════════════════════════════════════════════════════════
col_map, col_ctrl = st.columns([3, 2], gap="medium")

# ── LEFT: Map + Table ────────────────────────────────────────────────────────
with col_map:
    st.markdown('<div class="section-header">🛰 Geospatial Hotspot Map</div>',
                unsafe_allow_html=True)

    if not st.session_state.analysis_done:
        st.markdown("""
        <div style="background:linear-gradient(145deg,#030a03,#060f06);
             border:1px solid #00ff5025;border-radius:3px;height:320px;
             display:flex;align-items:center;justify-content:center;
             position:relative;overflow:hidden;">
          <div style="position:absolute;inset:0;
               background-image:
                 linear-gradient(rgba(0,255,80,.03) 1px,transparent 1px),
                 linear-gradient(90deg,rgba(0,255,80,.03) 1px,transparent 1px);
               background-size:28px 28px;"></div>
          <div style="font-family:'Orbitron',monospace;color:#00ff5050;
               font-size:.75rem;letter-spacing:3px;text-align:center;z-index:1;">
            [ AWAITING SCAN INITIATION ]<br><br>
            <span style="font-size:.6rem;color:#00ff5030;">
              Upload files → configure mission → launch FSI scan
            </span>
          </div>
        </div>""", unsafe_allow_html=True)
    else:
        df  = st.session_state.fsi_data
        geo = st.session_state.geo_data

        if geo is not None and not geo.empty:
            # Choropleth via plotly
            merged_geo = geo.merge(
                df[["district_norm", "FSI_Score", "Stress_Level", "Hotspot"]],
                on="district_norm", how="left"
            )
            merged_geo["FSI_Score"]   = merged_geo["FSI_Score"].fillna(0)
            merged_geo["Stress_Level"]= merged_geo["Stress_Level"].fillna("NO DATA")
            merged_geo["Hotspot"]     = merged_geo["Hotspot"].fillna(False)
            merged_geo["lon"] = merged_geo.geometry.centroid.x
            merged_geo["lat"] = merged_geo.geometry.centroid.y

            geojson = json.loads(merged_geo.to_json())

            fig_map = px.choropleth_mapbox(
                merged_geo,
                geojson=geojson,
                locations=merged_geo.index,
                color="FSI_Score",
                color_continuous_scale=["#003300","#00ff50","#ffaa00","#ff3300"],
                range_color=[0, 1],
                mapbox_style="carto-darkmatter",
                zoom=5.8,
                center={"lat": 15.3, "lon": 75.7},
                opacity=0.75,
                hover_data={"FSI_Score": ":.3f",
                            "Stress_Level": True,
                            "Hotspot": True},
                custom_data=["NAME_2","FSI_Score","Stress_Level","Hotspot"],
            )
            fig_map.update_traces(
                hovertemplate=(
                    "<b>%{customdata[0]}</b><br>"
                    "FSI Score: %{customdata[1]:.3f}<br>"
                    "Stress Level: %{customdata[2]}<br>"
                    "Hotspot: %{customdata[3]}<extra></extra>"
                )
            )
            fig_map.update_layout(
                paper_bgcolor="rgba(3,10,3,0)",
                margin=dict(l=0,r=0,t=0,b=0),
                height=330,
                coloraxis_colorbar=dict(
                    title="FSI",
                    tickfont=dict(color="#00ff50", family="Orbitron", size=9),
                    title_font=dict(color="#00ff50", family="Orbitron"),
                    bgcolor="rgba(3,10,3,.8)",
                    bordercolor="#00ff5030",
                )
            )
            st.plotly_chart(fig_map, use_container_width=True)
        else:
            # Fallback scatter map if shapefile not loaded
            fig_map = px.scatter_mapbox(
                df, lat="lat", lon="lon",
                size="FSI_Score", color="Stress_Level",
                hover_name="District",
                color_discrete_map={"LOW":"#00ff50","MEDIUM":"#ffaa00","HIGH":"#ff3300"},
                mapbox_style="carto-darkmatter",
                zoom=5.8, size_max=25,
                center={"lat":15.3,"lon":75.7}
            )
            fig_map.update_layout(
                paper_bgcolor="rgba(0,0,0,0)",
                margin=dict(l=0,r=0,t=0,b=0), height=330
            )
            st.plotly_chart(fig_map, use_container_width=True)

    # ── FSI District Scorecard ──
    if st.session_state.analysis_done:
        st.markdown('<div class="section-header">📊 FSI District Scorecard</div>',
                    unsafe_allow_html=True)
        df = st.session_state.fsi_data

        def color_stress(val):
            if val == "HIGH":   return "color:#ff3300;font-weight:bold"
            if val == "MEDIUM": return "color:#ffaa00;font-weight:bold"
            if val == "LOW":    return "color:#00ff50;font-weight:bold"
            return ""

        display_cols = ["District","FSI_Score","Stress_Level","Hotspot"]
        available    = [c for c in display_cols if c in df.columns]
        styled = (
            df[available]
            .sort_values("FSI_Score", ascending=False)
            .style
            .applymap(color_stress, subset=["Stress_Level"])
            .format({"FSI_Score": "{:.3f}"})
            .set_properties(**{"background-color":"#030a03","color":"#c8f0c0"})
        )
        st.dataframe(styled, use_container_width=True, height=230)

# ── RIGHT: Control Panel ─────────────────────────────────────────────────────
with col_ctrl:
    st.markdown('<div class="section-header">⚙ Mission Control</div>',
                unsafe_allow_html=True)

    # ── Stats when analysis is done ──
    if st.session_state.analysis_done:
        df       = st.session_state.fsi_data
        n_high   = (df.Stress_Level == "HIGH").sum()
        n_med    = (df.Stress_Level == "MEDIUM").sum()
        n_low    = (df.Stress_Level == "LOW").sum()
        avg_fsi  = df.FSI_Score.mean()
        n_hot    = df.Hotspot.sum() if "Hotspot" in df.columns else 0

        c1, c2 = st.columns(2)
        c1.metric("AVG FSI", f"{avg_fsi:.3f}",
                  delta="⚠ HIGH" if avg_fsi > 0.6 else "✓ OK")
        c2.metric("HOTSPOTS", int(n_hot), delta=f"{n_high} critical")

        st.markdown(f"""
        <div class="hud-card" style="margin-top:.4rem;">
          <div class="hud-label">Threat Distribution</div>
          <div style="margin-top:.4rem;">
            <div style="display:flex;justify-content:space-between;margin-bottom:.25rem;">
              <span>HIGH STRESS</span><span class="badge-high">■ {n_high} districts</span>
            </div>
            <div class="stress-bar-bg"><div class="stress-bar-fill"
              style="width:{int(n_high/max(len(df),1)*100)}%;background:#ff3300;">
            </div></div>
            <div style="display:flex;justify-content:space-between;margin:.45rem 0 .25rem;">
              <span>MEDIUM</span><span class="badge-medium">■ {n_med} districts</span>
            </div>
            <div class="stress-bar-bg"><div class="stress-bar-fill"
              style="width:{int(n_med/max(len(df),1)*100)}%;background:#ffaa00;">
            </div></div>
            <div style="display:flex;justify-content:space-between;margin:.45rem 0 .25rem;">
              <span>LOW</span><span class="badge-low">■ {n_low} districts</span>
            </div>
            <div class="stress-bar-bg"><div class="stress-bar-fill"
              style="width:{int(n_low/max(len(df),1)*100)}%;background:#00ff50;">
            </div></div>
          </div>
        </div>""", unsafe_allow_html=True)

    # ── Action Buttons ──
    b1, b2 = st.columns(2)

    with b1:
        launch = st.button("🚀 LAUNCH FSI SCAN")
    with b2:
        reset  = st.button("🔄 RESET MISSION")

    if reset:
        st.session_state.analysis_done = False
        st.session_state.fsi_data      = None
        st.session_state.geo_data      = None
        add_log("Mission board cleared. Awaiting new scan.", "normal")
        st.rerun()

    if launch:
        if not uploaded_xlsx:
            st.error("⚠ Upload the XLSX dataset first.")
            add_log("Launch aborted — no dataset uploaded.", "warn")
        elif not indicators:
            st.warning("Select at least one stress indicator.")
        else:
            with st.spinner("🛰 Running spatial FSI analysis..."):
                try:
                    # 1. Load Excel
                    add_log(f"Loading dataset for {selected_state} · {selected_year}…")
                    sheets = load_excel(uploaded_xlsx.read())

                    # 2. Build merged FSI dataframe
                    df = build_fsi_dataframe(sheets, selected_year, selected_state)
                    if df.empty:
                        st.error(f"No data found for {selected_state} / {selected_year}.")
                        add_log("No matching data found.", "warn")
                    else:
                        # 3. ML classification
                        df = classify_stress(df, feature_cols=indicators)
                        # 4. Hotspot detection
                        df = detect_hotspots(df, threshold=hotspot_threshold)

                        # 5. Load shapefile if provided
                        geo = None
                        if uploaded_zip:
                            add_log("Loading boundary shapefile…")
                            geo = load_shapefile(uploaded_zip.read(), selected_state)

                        st.session_state.fsi_data      = df
                        st.session_state.geo_data      = geo
                        st.session_state.analysis_done = True
                        gain_xp(50)
                        n_hot = df.Hotspot.sum() if "Hotspot" in df.columns else 0
                        add_log(
                            f"FSI Scan complete — {selected_state} · {len(df)} districts"
                            f" · {int(n_hot)} hotspots · Year {selected_year}", "warn"
                        )
                        st.rerun()
                except Exception as e:
                    st.error(f"Analysis failed: {e}")
                    add_log(f"ERROR: {e}", "alert")

    # ── Indicator Breakdown Chart ──
    if st.session_state.analysis_done:
        avail_ind = [c for c in indicators if c in st.session_state.fsi_data.columns]
        if avail_ind:
            st.markdown('<div class="section-header">📡 Indicator Breakdown</div>',
                        unsafe_allow_html=True)
            df      = st.session_state.fsi_data
            raw_avg = df[avail_ind].mean()
            # Normalise to 0-1 for display
            norm_avg = (raw_avg - raw_avg.min()) / (raw_avg.max() - raw_avg.min() + 1e-9)
            avg_df   = norm_avg.reset_index()
            avg_df.columns = ["Indicator", "Score"]

            fig_bar = go.Figure(go.Bar(
                x=avg_df["Score"], y=avg_df["Indicator"],
                orientation="h",
                marker=dict(
                    color=avg_df["Score"],
                    colorscale=[[0,"#003300"],[0.5,"#ffaa00"],[1,"#ff3300"]],
                    line=dict(color="#00ff5025", width=1)
                ),
                text=[f"{v:.2f}" for v in avg_df["Score"]],
                textposition="outside",
                textfont=dict(color="#c8f0c0", family="Rajdhani")
            ))
            fig_bar.update_layout(
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(3,10,3,.9)",
                font=dict(family="Rajdhani", color="#c8f0c0", size=11),
                xaxis=dict(showgrid=True, gridcolor="#00ff5012",
                           range=[0, 1.25], tickfont=dict(color="#35bb50")),
                yaxis=dict(showgrid=False, tickfont=dict(color="#c8f0c0")),
                margin=dict(l=0,r=45,t=5,b=5), height=190
            )
            st.plotly_chart(fig_bar, use_container_width=True)

        # ── Download ──
        csv_bytes = st.session_state.fsi_data.to_csv(index=False).encode()
        st.download_button(
            label="⬇ EXPORT FSI REPORT (CSV)",
            data=csv_bytes,
            file_name=f"FSI_{selected_state}_{selected_year}.csv",
            mime="text/csv",
        )

# ════════════════════════════════════════════════════════════════════════════
# MISSION LOG
# ════════════════════════════════════════════════════════════════════════════
st.markdown('<div class="section-header">📋 Mission Log</div>', unsafe_allow_html=True)

if not st.session_state.log:
    add_log("System online. Upload dataset + shapefile, then launch FSI scan.", "normal")

log_html = "<div class='mission-log'>"
for ts, msg, kind in st.session_state.log:
    cls  = {"normal":"log-line","warn":"log-line-warn","alert":"log-line-alert"}[kind]
    icon = {"normal":"›","warn":"⚠","alert":"★"}[kind]
    log_html += (f"<div class='{cls}'>"
                 f"<span class='log-time'>[{ts}]</span>{icon} {msg}</div>")
log_html += "</div>"
st.markdown(log_html, unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════════════════
# FOOTER
# ════════════════════════════════════════════════════════════════════════════
st.markdown("""
<div class="footer">
  AGRISTRESS AVENGERS · FSI COMMAND v2.0 · SPATIAL INTELLIGENCE DIVISION · 2024-25
</div>""", unsafe_allow_html=True)
